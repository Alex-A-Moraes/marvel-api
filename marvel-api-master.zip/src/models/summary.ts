import { model, Schema, Document, Model } from 'mongoose';

export interface ISummary extends Document {
    resourceURI: string;
    name: string;
    role: string;
}

const SummarySchema = new Schema({
    resourceURI: String,
    name: String,
    role: String,
});

export default SummarySchema;
export const Summary: Model<ISummary> = model<ISummary>('summaries', SummarySchema);
