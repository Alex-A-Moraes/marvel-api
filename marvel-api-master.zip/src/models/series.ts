import { model, Schema } from 'mongoose';

const SeriesSchema = new Schema({
    id: Number,
    title: String,
    description: String,
    resourceURI: String,
    type: String,
    modified: String,
    thumbnail: [
        {
            type: Schema.Types.ObjectId,
            ref: 'image',
        },
    ],
    comics: [
        {
            type: Schema.Types.ObjectId,
            ref: 'summary',
        },
    ],
    series: [
        {
            type: Schema.Types.ObjectId,
            ref: 'summary',
        },
    ],
    events: [
        {
            type: Schema.Types.ObjectId,
            ref: 'summary',
        },
    ],
    characters: [
        {
            type: Schema.Types.ObjectId,
            ref: 'summary',
        },
    ],
    creators: [
        {
            type: Schema.Types.ObjectId,
            ref: 'summary',
        },
    ],
    originalissue: [
        {
            type: Schema.Types.ObjectId,
            ref: 'summary',
        },
    ],
});

export default model('series', SeriesSchema);
