import { model, Schema, Document, Model } from 'mongoose';
import { Summary } from './summary';

export type StoryDocument = Document & {
    id: number;
    title: string;
    description: string;
    resourceURI: string;
    type: string;
    modified: string;
    thumbnail: string[];
    comics: string[];
    series: string[];
    events: string[];
    characters: string[];
    creators: string[];
    originalissue: string[];
};

const StorySchema = new Schema({
    id: Number,
    title: String,
    description: String,
    resourceURI: String,
    type: String,
    modified: String,
    thumbnail: [
        {
            type: Schema.Types.ObjectId,
            ref: 'image',
        },
    ],
    comics: [
        {
            type: Schema.Types.ObjectId,
            ref: 'summaries',
        },
    ],
});

export default StorySchema;
export const Story: Model<StoryDocument> = model<StoryDocument>('story', StorySchema);
