import { connect, connection } from 'mongoose';
import Story from '../../src/models/story';
import Summary from '../../src/models/summary';

describe('Characters', () => {
    beforeAll(async () => {
        await connect(`mongodb://localhost:27017/marvel`);
    });

    afterAll(async () => {
        await connection.close();
    });

    it('it should insert story', async () => {
        const ComicSummary = await Summary.create({
            resourceURI: 'http://gateway.marvel.com/v1/public/comics/10223',
            name: 'Marvel Premiere (1972) #35',
            role: null,
        });

        const story = await Story.create({
            id: Number(19947),
            title: 'Cover #19947',
            description: '',
            resourceURI: 'http://gateway.marvel.com/v1/public/stories/19947',
            type: 'cover',
            modified: '1969-12-31T19:00:00-0500',
            thumbnail: null,
            comics: [ComicSummary._id],
        });

        expect(200).toBe(200);
    });
});
